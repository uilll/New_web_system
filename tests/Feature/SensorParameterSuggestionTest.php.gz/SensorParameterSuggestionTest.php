<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\DatabaseMigrations;
use TestCase;
use Tobuli\Entities\Device;

class SensorParameterSuggestionTest extends TestCase
{
//    use DatabaseMigrations;
//    /** @test */
//    public function response_if_no_param_data_in_database()
//    {
//        //$device = create(Device::class);
//        //$this->get(route('sensors.param', ''));
//        $this->assertTrue(true);
//    }
}