<?php namespace Tobuli\Repositories\TrackerPort;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface TrackerPortRepositoryInterface extends EloquentRepositoryInterface {
}