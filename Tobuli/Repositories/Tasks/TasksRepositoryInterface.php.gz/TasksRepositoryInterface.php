<?php namespace Tobuli\Repositories\Tasks;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface TasksRepositoryInterface extends EloquentRepositoryInterface {

}