<?php namespace Tobuli\Repositories\SensorGroupSensor;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface SensorGroupSensorRepositoryInterface extends EloquentRepositoryInterface {

}