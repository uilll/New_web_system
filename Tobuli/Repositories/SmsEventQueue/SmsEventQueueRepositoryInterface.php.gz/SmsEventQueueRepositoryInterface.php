<?php namespace Tobuli\Repositories\SmsEventQueue;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface SmsEventQueueRepositoryInterface extends EloquentRepositoryInterface {


}