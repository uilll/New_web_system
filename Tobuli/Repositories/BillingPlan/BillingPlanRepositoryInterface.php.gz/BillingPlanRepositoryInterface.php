<?php namespace Tobuli\Repositories\BillingPlan;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface BillingPlanRepositoryInterface extends EloquentRepositoryInterface {
}