<?php namespace Tobuli\Repositories\EventCustom;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface EventCustomRepositoryInterface extends EloquentRepositoryInterface {

}