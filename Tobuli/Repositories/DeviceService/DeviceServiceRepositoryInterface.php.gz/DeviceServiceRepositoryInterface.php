<?php namespace Tobuli\Repositories\DeviceService;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceServiceRepositoryInterface extends EloquentRepositoryInterface {
}