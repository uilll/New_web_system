<?php namespace Tobuli\Repositories\ReportLog;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface ReportLogRepositoryInterface extends EloquentRepositoryInterface {

}