<?php namespace Tobuli\Repositories\DeviceFuelMeasurement;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface DeviceFuelMeasurementRepositoryInterface extends EloquentRepositoryInterface {

}