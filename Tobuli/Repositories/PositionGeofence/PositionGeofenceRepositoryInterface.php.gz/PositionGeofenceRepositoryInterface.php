<?php namespace Tobuli\Repositories\PositionGeofence;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface PositionGeofenceRepositoryInterface extends EloquentRepositoryInterface {

}