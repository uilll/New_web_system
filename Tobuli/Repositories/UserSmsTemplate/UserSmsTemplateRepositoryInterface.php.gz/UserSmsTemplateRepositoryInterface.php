<?php namespace Tobuli\Repositories\UserSmsTemplate;

use Tobuli\Repositories\EloquentRepositoryInterface;

interface UserSmsTemplateRepositoryInterface extends EloquentRepositoryInterface {

}