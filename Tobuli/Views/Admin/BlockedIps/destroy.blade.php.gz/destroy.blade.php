@extends('Frontend.Layouts.modal')

@section('title', trans('global.delete'))

@section('body')
    {!! Form::open(['route' => 'admin.blocked_ips.destroy', 'method' => 'DELETE']) !!}
        {!! Form::hidden('id', $file) !!}
        {{ trans('front.do_delete') }}
    {!! Form::close() !!}
@stop

@section('buttons')
    <button type="button" class="btn btn-action update">{{ trans('global.yes') }}</button>
    <button type="button" class="btn btn-default" data-dismiss="modal">{{ trans('global.no') }}</button>
@stop